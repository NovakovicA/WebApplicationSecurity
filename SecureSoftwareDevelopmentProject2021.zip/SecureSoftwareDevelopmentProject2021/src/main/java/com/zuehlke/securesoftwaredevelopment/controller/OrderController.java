package com.zuehlke.securesoftwaredevelopment.controller;

import com.google.gson.Gson;
import com.zuehlke.securesoftwaredevelopment.domain.Food;
import com.zuehlke.securesoftwaredevelopment.domain.NewOrder;
import com.zuehlke.securesoftwaredevelopment.domain.User;
import com.zuehlke.securesoftwaredevelopment.repository.CustomerRepository;
import com.zuehlke.securesoftwaredevelopment.repository.OrderRepository;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class OrderController {
    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;

    public OrderController(OrderRepository orderRepository, CustomerRepository customerRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
    }

    @GetMapping("/order")
    @PreAuthorize("hasAuthority('ORDER_FOOD')")
    public String order(Model model,HttpSession session){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();
        model.addAttribute("CSRF_TOKEN", session.getAttribute("CSRF_TOKEN"));
        model.addAttribute("restaurants", customerRepository.getRestaurants());
        model.addAttribute("addresses", orderRepository.getAddresses(user.getId()));
        return "order";
    }


    @GetMapping(value = "/api/menu", produces = "application/json")
    @ResponseBody
    public List<Food> getMenu(@RequestParam(name="id") String id){
        int identificator = Integer.valueOf(id);
        return orderRepository.getMenu(identificator);
    }

    @PostMapping(value = "/api/new-order")
    @ResponseBody
    @PreAuthorize("hasAuthority('ORDER_FOOD')")
    public String newOrder(@RequestParam("neworder") String newOrderString, HttpSession session, @RequestParam("csrfToken") String csrfToken){
        String csrf=session.getAttribute("CSRF_TOKEN").toString();
        if(!csrf.equals(csrfToken)){
            throw new AccessDeniedException("Forbidden access.");
        }

        Gson gson = new Gson();
        NewOrder newOrder =  gson.fromJson(newOrderString, NewOrder.class);;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();
        orderRepository.insertNewOrder(newOrder, user.getId());
        return "";
    }
}
