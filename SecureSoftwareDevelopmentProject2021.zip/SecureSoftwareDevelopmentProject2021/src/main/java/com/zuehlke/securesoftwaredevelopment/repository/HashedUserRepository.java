package com.zuehlke.securesoftwaredevelopment.repository;

import com.zuehlke.securesoftwaredevelopment.config.AuditLogger;
import com.zuehlke.securesoftwaredevelopment.domain.HashedUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;

@Repository
public class HashedUserRepository {

    private static final Logger LOG = LoggerFactory.getLogger(HashedUserRepository.class);
    private static final AuditLogger auditLogger = AuditLogger.getAuditLogger(HashedUserRepository.class);


    private final DataSource dataSource;

    public HashedUserRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public HashedUser findUser(String username) {
        String sqlQuery = "select passwordHash, salt, totpKey from hashedUsers where username = ?";
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlQuery);
             ) {
            statement.setString(1,username);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String passwordHash = rs.getString(1);
                String salt = rs.getString(2);
                String totpKey = rs.getString(3);
                LOG.info("findUser - Successfully returning found hashed user.");
                return new HashedUser(username, passwordHash, salt, totpKey);
            }
        } catch (SQLException e) {
            LOG.error("findUser - Error on getting Hashed User [username=" + username + "] from database.",e);
        }
        LOG.info("findUser - Couldn't find hashed user within the database.");
        return null;
    }

    public void saveTotpKey(String username, String totpKey) {
        String sqlQuery = "update hashedUsers set totpKey = ? where username = ?";
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setString(1, totpKey);
            statement.setString(2, username);

            statement.executeUpdate();
            LOG.info("saveTotpKey - Successfully saved totpKey for user [username=" + username + "].");
        } catch (SQLException e) {
            LOG.error("saveTotpKey - Error on saving totp key [username=" + username + "] to database.",e);
        }
    }
}
